# Basketball Android App

A complete Android Studio/Gradle project that wraps the Basketball HTML game in an Android WebView.

## Build

### Android Studio
Open this folder as a Gradle project and let Android Studio sync.

### Command line
Use Java 17 and Gradle 8.13:
```bash
./gradlew bundleRelease
```

The AAB will be created at:
`app/build/outputs/bundle/release/app-release.aab`

## GitHub Actions
The included workflow bootstraps the Gradle wrapper if necessary, builds the release AAB, and uploads it as a workflow artifact.
